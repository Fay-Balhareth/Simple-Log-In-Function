package com.example.group1cs1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    ImageView avatar;
    TextView welcome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        avatar = findViewById(R.id.avatar);
        welcome = findViewById(R.id.welcomeTextView);
        Intent intent = getIntent();
        String username = intent.getStringExtra("USERNAME");

        welcome.setText("Welcome, " + username + "!");

        Toast.makeText(this, "Logged In Successfully", Toast.LENGTH_SHORT).show();
    }
    }
